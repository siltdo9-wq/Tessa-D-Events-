import { useEffect, useMemo, useRef, useState } from "react";

type QuoteItem = {
  id: string;
  name: string;
  category: "Mobilier" | "Décoration" | "Accessoires" | "Services";
  unitPrice: number;
  qty: number;
  image: string;
};

type FormData = {
  nom: string;
  email: string;
  telephone: string;
  date: string;
  type: string;
  invites: string;
  message: string;
  lieu: string;
};

const initialCatalog: QuoteItem[] = [
  {
    id: "chaise-chiavari-or",
    name: "Chaise Chiavari Or",
    category: "Mobilier",
    unitPrice: 4.5,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/apexpartyrentals.com/6b40b956491cb5c6db5fb5df33bdb1a0af2792cd.png",
  },
  {
    id: "chaise-chiavari-transparent",
    name: "Chaise Chiavari Transparente",
    category: "Mobilier",
    unitPrice: 5.0,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/curatedevents.com/d6cd880e6aa22fd58226e35c5c968e597c35058f.webp",
  },
  {
    id: "table-ronde-10",
    name: "Table ronde Ø180 (10 pers.)",
    category: "Mobilier",
    unitPrice: 18,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/www.venturarental.com/2b4e8fd1f092147e1c654b5ec72e77a2751614db.webp",
  },
  {
    id: "table-rectangulaire",
    name: "Table rectangulaire 220x80",
    category: "Mobilier",
    unitPrice: 15,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/southerneventsonline.com/481751c14e2f8f338470b13820432221009cc867.jpg",
  },
  {
    id: "mange-debout",
    name: "Mange-debout + housse",
    category: "Mobilier",
    unitPrice: 12,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/curatedevents.com/9b872ae167562006ea644f8dac62b0b6f70150e5.webp",
  },
  {
    id: "arche-florale",
    name: "Arche florale sur mesure",
    category: "Décoration",
    unitPrice: 350,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/www.valarflowers.com/7694f3d1efe594fcdabada3b81a880d99baac204.jpg",
  },
  {
    id: "centre-table",
    name: "Centre de table (floral)",
    category: "Décoration",
    unitPrice: 25,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/generalwax.com/195b4e0974eda929d87e448850b320302f08d2cd.jpg",
  },
  {
    id: "chemin-table",
    name: "Chemin de table voile",
    category: "Décoration",
    unitPrice: 6,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/treasuryontheplaza.com/0defb7378a71023e697a570c307e7cb49af4a89c.jpeg",
  },
  {
    id: "bougies-led",
    name: "Lot 20 bougies LED + photophores",
    category: "Accessoires",
    unitPrice: 28,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/static.wixstatic.com/082df7346e0abe118e6cc7072f547e7e719e69ea.jpg",
  },
  {
    id: "vaiselle-complete",
    name: "Set vaisselle/verrerie (par pers.)",
    category: "Accessoires",
    unitPrice: 3.8,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/generalwax.com/195b4e0974eda929d87e448850b320302f08d2cd.jpg",
  },
  {
    id: "nappe-ronde",
    name: "Nappe ronde Ø320 cm",
    category: "Accessoires",
    unitPrice: 9,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/treasuryontheplaza.com/0defb7378a71023e697a570c307e7cb49af4a89c.jpeg",
  },
  {
    id: "signaletique",
    name: "Signalétique bois personnalisée",
    category: "Accessoires",
    unitPrice: 45,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/static.wixstatic.com/082df7346e0abe118e6cc7072f547e7e719e69ea.jpg",
  },
  {
    id: "installation",
    name: "Installation & mise en place",
    category: "Services",
    unitPrice: 180,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/curatedevents.com/9b872ae167562006ea644f8dac62b0b6f70150e5.webp",
  },
  {
    id: "livraison",
    name: "Livraison & reprise (forfait)",
    category: "Services",
    unitPrice: 120,
    qty: 0,
    image: "https://kimi-web-img.moonshot.cn/img/southerneventsonline.com/481751c14e2f8f338470b13820432221009cc867.jpg",
  },
];

const formatPrice = (n: number) =>
  new Intl.NumberFormat("fr-BE", { style: "currency", currency: "EUR" }).format(n);

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [slide, setSlide] = useState(0);
  const [modalOpen, setModalOpen] = useState(false);
  const [signatureModalOpen, setSignatureModalOpen] = useState(false);
  const [items, setItems] = useState<QuoteItem[]>(initialCatalog);
  const [quoteRef, setQuoteRef] = useState<string>("");
  const [form, setForm] = useState<FormData>({
    nom: "",
    email: "",
    telephone: "",
    date: "",
    type: "mariage",
    invites: "50-100",
    message: "",
    lieu: "",
  });
  const [copied, setCopied] = useState(false);
  const [signatureData, setSignatureData] = useState<string | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const signatureCanvasRef = useRef<HTMLCanvasElement>(null);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);

  const slides = [
    "https://kimi-web-img.moonshot.cn/img/southerneventsonline.com/481751c14e2f8f338470b13820432221009cc867.jpg",
    "https://kimi-web-img.moonshot.cn/img/curatedevents.com/d6cd880e6aa22fd58226e35c5c968e597c35058f.webp",
    "https://kimi-web-img.moonshot.cn/img/treasuryontheplaza.com/0defb7378a71023e697a570c307e7cb49af4a89c.jpeg",
  ];

  // header scroll
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // slider auto
  useEffect(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % slides.length), 5000);
    return () => clearInterval(id);
  }, [slides.length]);

  // fade-in observer
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("visible");
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
    );
    document.querySelectorAll(".fade-in").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const totals = useMemo(() => {
    const subtotal = items.reduce((sum, it) => sum + it.unitPrice * it.qty, 0);
    const tva = subtotal * 0.21;
    const total = subtotal + tva;
    const count = items.reduce((c, it) => c + it.qty, 0);
    return { subtotal, tva, total, count };
  }, [items]);

  useEffect(() => {
    if (!quoteRef) {
      const now = new Date();
      const yy = String(now.getFullYear()).slice(-2);
      const mm = String(now.getMonth() + 1).padStart(2, "0");
      const dd = String(now.getDate()).padStart(2, "0");
      const rand = Math.floor(1000 + Math.random() * 9000);
      setQuoteRef(`TD-${yy}${mm}${dd}-${rand}`);
    }
  }, [quoteRef]);

  const updateQty = (id: string, delta: number) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === id ? { ...it, qty: Math.max(0, it.qty + delta) } : it
      )
    );
  };

  const setQty = (id: string, v: number) => {
    const n = Number.isFinite(v) ? Math.max(0, Math.floor(v)) : 0;
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, qty: n } : it)));
  };

  const resetQuote = () => {
    setItems((prev) => prev.map((it) => ({ ...it, qty: 0 })));
    setSignatureData(null);
  };

  const selectedItems = useMemo(() => items.filter((i) => i.qty > 0), [items]);

  const buildQuoteText = () => {
    const lines: string[] = [];
    lines.push(`═══════════════════════════════════════`);
    lines.push(`   DEVIS — Tessa & D Events`);
    lines.push(`═══════════════════════════════════════`);
    lines.push(``);
    lines.push(`Référence: ${quoteRef}`);
    lines.push(`Date d'émission: ${new Date().toLocaleDateString("fr-BE", { day: '2-digit', month: 'long', year: 'numeric' })}`);
    lines.push(`Validité: 30 jours`);
    lines.push(``);
    lines.push(`CLIENT`);
    lines.push(`───────────────────────────────────────`);
    lines.push(`Nom: ${form.nom || "-"}`);
    lines.push(`Email: ${form.email || "-"}`);
    lines.push(`Téléphone: ${form.telephone || "-"}`);
    lines.push(`Date événement: ${form.date ? new Date(form.date).toLocaleDateString("fr-BE") : "-"}`);
    lines.push(`Type: ${form.type.charAt(0).toUpperCase() + form.type.slice(1)}`);
    lines.push(`Invités: ${form.invites}`);
    lines.push(`Lieu: ${form.lieu || "-"}`);
    lines.push(``);
    lines.push(`DÉTAIL DE LA PRESTATION`);
    lines.push(`───────────────────────────────────────`);
    if (selectedItems.length === 0) {
      lines.push(`(Aucun article sélectionné)`);
    } else {
      selectedItems.forEach((it) => {
        const lineTotal = it.unitPrice * it.qty;
        lines.push(`${it.name}`);
        lines.push(`  ${it.qty} × ${formatPrice(it.unitPrice)} = ${formatPrice(lineTotal)}`);
      });
    }
    lines.push(``);
    lines.push(`RÉCAPITULATIF`);
    lines.push(`───────────────────────────────────────`);
    lines.push(`Sous-total HTVA ........... ${formatPrice(totals.subtotal).padStart(12)}`);
    lines.push(`TVA 21% ................... ${formatPrice(totals.tva).padStart(12)}`);
    lines.push(`TOTAL TTC ................. ${formatPrice(totals.total).padStart(12)}`);
    lines.push(``);
    if (form.message?.trim()) {
      lines.push(`NOTES`);
      lines.push(`───────────────────────────────────────`);
      lines.push(form.message.trim());
      lines.push(``);
    }
    if (signatureData) {
      lines.push(`SIGNATURE CLIENT`);
      lines.push(`───────────────────────────────────────`);
      lines.push(`✓ Devis signé électroniquement le ${new Date().toLocaleDateString("fr-BE")} à ${new Date().toLocaleTimeString("fr-BE", { hour: '2-digit', minute: '2-digit' })}`);
      lines.push(`Par: ${form.nom}`);
      lines.push(``);
    }
    lines.push(`═══════════════════════════════════════`);
    lines.push(`Tessa & D Events`);
    lines.push(`📞 0492 85 91 27`);
    lines.push(`✉️  contact@tessaetdevents.be`);
    lines.push(`📍 Basés à Liège - Intervention Belgique`);
    lines.push(`═══════════════════════════════════════`);
    return lines.join("\n");
  };

  const copyQuote = async () => {
    await navigator.clipboard.writeText(buildQuoteText());
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const downloadQuote = () => {
    const blob = new Blob([buildQuoteText()], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `devis-${quoteRef}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  // Signature canvas handlers
  const initSignatureCanvas = () => {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    // Set actual size in memory (scaled to device pixel ratio)
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    
    // Set drawing styles
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = "#4A4A4A";
    
    // Clear with white background
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, rect.width, rect.height);
  };

  useEffect(() => {
    if (signatureModalOpen) {
      setTimeout(initSignatureCanvas, 100);
    }
  }, [signatureModalOpen]);

  const getCanvasPoint = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    setIsDrawing(true);
    lastPointRef.current = getCanvasPoint(e);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    e.preventDefault();
    const canvas = signatureCanvasRef.current;
    const ctx = canvas?.getContext("2d");
    const point = getCanvasPoint(e);
    if (!ctx || !point || !lastPointRef.current) return;

    ctx.beginPath();
    ctx.moveTo(lastPointRef.current.x, lastPointRef.current.y);
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
    lastPointRef.current = point;
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    lastPointRef.current = null;
  };

  const clearSignature = () => {
    initSignatureCanvas();
    setSignatureData(null);
  };

  const saveSignature = () => {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL("image/png");
    setSignatureData(dataUrl);
    setSignatureModalOpen(false);
  };

  const submitQuote = (e: React.FormEvent) => {
    e.preventDefault();
    if (totals.count === 0) {
      alert("Veuillez sélectionner au moins un article pour votre devis.");
      return;
    }
    if (!signatureData) {
      setSignatureModalOpen(true);
      return;
    }
    setModalOpen(true);
  };

  const scrollToId = (id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    const headerOffset = 92;
    const y = el.getBoundingClientRect().top + window.pageYOffset - headerOffset;
    window.scrollTo({ top: y, behavior: "smooth" });
    setMobileOpen(false);
  };

  return (
    <div className="tessadevents">
      {/* Styles intégrés */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Montserrat:wght@300;400;500;600&display=swap');
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

        :root {
          --primary: #D4A5A5;
          --primary-dark: #B88A8A;
          --secondary: #F5E6E0;
          --accent: #E8D5D0;
          --text-dark: #4A4A4A;
          --text-light: #7A7A7A;
          --white: #FFFFFF;
          --cream: #FAF7F5;
          --gold: #C9B037;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; overflow-x: hidden; width: 100%; }
        body { font-family: 'Montserrat', sans-serif; color: var(--text-dark); background-color: var(--cream); line-height: 1.6; overflow-x: hidden; width: 100%; max-width: 100vw; }
        h1, h2, h3, h4, h5, h6 { font-family: 'Cormorant Garamond', serif; font-weight: 600; line-height: 1.2; }

        .top-bar {
          background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
          color: var(--white); padding: 0.4rem 1rem; font-size: 0.8rem; position: fixed; width: 100%; top: 0; z-index: 1001;
          box-shadow: 0 1px 5px rgba(0,0,0,0.1); height: 32px; display: flex; align-items: center; justify-content: center;
        }
        .top-bar-content { max-width: 1200px; width: 100%; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; gap: 1rem; }
        .top-bar-left { display: flex; align-items: center; gap: 0.5rem; }
        .top-bar a { color: var(--white); text-decoration: none; font-weight: 500; transition: opacity 0.3s; white-space: nowrap; }
        .top-bar a:hover { opacity: 0.9; }
        .top-bar i { margin-right: 0.3rem; font-size: 0.75rem; }
        .top-bar-text { font-size: 0.75rem; opacity: 0.9; white-space: nowrap; }

        header { background: var(--white); box-shadow: 0 2px 15px rgba(0,0,0,0.05); position: fixed; width: 100%; top: 32px; z-index: 1000; transition: all 0.3s ease; height: 60px; display: flex; align-items: center; }
        header.scrolled { box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        nav { max-width: 1200px; width: 100%; margin: 0 auto; padding: 0 1.5rem; display: flex; justify-content: space-between; align-items: center; }
        .logo { font-family: 'Cormorant Garamond', serif; font-size: 1.4rem; font-weight: 600; color: var(--text-dark); text-decoration: none; display: flex; align-items: center; gap: 0.4rem; white-space: nowrap; flex-shrink: 0; }
        .logo i { font-size: 1rem; color: var(--primary); }
        .logo span { color: var(--primary-dark); }
        .nav-links { display: flex; list-style: none; gap: 1.5rem; align-items: center; margin: 0; padding: 0; }
        .nav-links a { text-decoration: none; color: var(--text-dark); font-weight: 500; font-size: 0.85rem; position: relative; transition: color 0.3s; white-space: nowrap; }
        .nav-links a::after { content: ''; position: absolute; bottom: -4px; left: 0; width: 0; height: 2px; background: var(--primary); transition: width 0.3s ease; }
        .nav-links a:hover::after { width: 100%; }
        .nav-links a:hover { color: var(--primary-dark); }
        .nav-links .btn { padding: 0.5rem 1rem; font-size: 0.8rem; margin-left: 0.5rem; }
        .mobile-menu { display: none; font-size: 1.2rem; cursor: pointer; color: var(--text-dark); padding: 0.4rem; background: none; border: none; flex-shrink: 0; }

        .hero { margin-top: 92px; min-height: calc(100vh - 92px); max-height: 800px; position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; width: 100%; }
        .hero-slider { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; }
        .slide { position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; transition: opacity 1.2s ease-in-out; background-size: cover; background-position: center; background-repeat: no-repeat; }
        .slide.active { opacity: 1; }
        .slide::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.4) 100%); }
        .hero-content { position: relative; z-index: 2; text-align: center; color: var(--white); max-width: 700px; padding: 2rem; width: 100%; }
        .hero h1 { font-size: clamp(1.8rem, 4vw, 3rem); margin-bottom: 1rem; text-shadow: 2px 2px 4px rgba(0,0,0,0.3); font-style: italic; font-weight: 600; line-height: 1.2; }
        .hero p { font-size: clamp(0.95rem, 2vw, 1.2rem); margin-bottom: 2rem; font-weight: 300; text-shadow: 1px 1px 2px rgba(0,0,0,0.3); line-height: 1.6; max-width: 550px; margin-left: auto; margin-right: auto; }
        .hero-buttons { display: flex; gap: 0.8rem; justify-content: center; flex-wrap: wrap; }
        .btn { display: inline-block; padding: 0.9rem 1.8rem; background: var(--primary); color: var(--white); text-decoration: none; border-radius: 50px; font-weight: 500; transition: all 0.3s ease; border: 2px solid var(--primary); cursor: pointer; font-size: 0.95rem; text-align: center; white-space: nowrap; }
        .btn:hover { background: transparent; color: var(--white); transform: translateY(-2px); box-shadow: 0 8px 25px rgba(212, 165, 165, 0.4); }
        .btn-outline { background: transparent; border: 2px solid var(--white); }
        .btn-outline:hover { background: var(--white); color: var(--text-dark); }
        .btn-cream { background: var(--white); color: var(--text-dark); border-color: var(--accent); }
        .btn-cream:hover { background: var(--cream); color: var(--text-dark); box-shadow: 0 8px 20px rgba(0,0,0,0.06); border-color: var(--primary); }
        .slider-dots { position: absolute; bottom: 30px; left: 50%; transform: translateX(-50%); z-index: 3; display: flex; gap: 10px; }
        .dot { width: 10px; height: 10px; border-radius: 50%; background: rgba(255,255,255,0.4); cursor: pointer; transition: all 0.3s ease; border: 2px solid transparent; }
        .dot.active { background: var(--white); transform: scale(1.2); border-color: var(--primary); }
        .scroll-indicator { position: absolute; bottom: 70px; left: 50%; transform: translateX(-50%); z-index: 3; animation: bounce 2s infinite; }
        .scroll-indicator i { color: var(--white); font-size: 1.5rem; opacity: 0.8; }
        @keyframes bounce { 0%, 20%, 50%, 80%, 100% { transform: translateX(-50%) translateY(0); } 40% { transform: translateX(-50%) translateY(-8px); } 60% { transform: translateX(-50%) translateY(-4px); } }

        section { padding: 4rem 1.5rem; max-width: 1200px; margin: 0 auto; width: 100%; }
        .section-title { text-align: center; margin-bottom: 2.5rem; padding: 0 0.5rem; }
        .section-title h2 { font-size: clamp(1.6rem, 3.5vw, 2.2rem); color: var(--text-dark); margin-bottom: 0.8rem; position: relative; display: inline-block; }
        .section-title h2::after { content: ''; position: absolute; bottom: -8px; left: 50%; transform: translateX(-50%); width: 50px; height: 3px; background: var(--primary); }
        .section-title p { color: var(--text-light); font-size: 1rem; max-width: 550px; margin: 1.2rem auto 0; line-height: 1.6; }

        .about { background: var(--white); padding: 4rem 1.5rem; width: 100%; }
        .about-content { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; align-items: center; max-width: 1200px; margin: 0 auto; width: 100%; }
        .about-text h3 { font-size: clamp(1.4rem, 3vw, 1.8rem); margin-bottom: 1.2rem; color: var(--text-dark); }
        .about-text p { margin-bottom: 1.2rem; color: var(--text-light); line-height: 1.7; font-size: 0.95rem; }
        .values { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-top: 2rem; }
        .value-card { text-align: center; padding: 1.2rem 0.8rem; background: var(--cream); border-radius: 10px; transition: all 0.3s ease; border: 1px solid transparent; }
        .value-card:hover { transform: translateY(-3px); border-color: var(--accent); box-shadow: 0 8px 20px rgba(0,0,0,0.05); }
        .value-card i { font-size: 1.6rem; color: var(--primary); margin-bottom: 0.6rem; }
        .value-card h4 { font-size: 1rem; margin-bottom: 0.3rem; color: var(--text-dark); }
        .value-card p { font-size: 0.8rem; color: var(--text-light); margin: 0; line-height: 1.4; }
        .about-image { position: relative; border-radius: 10px; overflow: hidden; box-shadow: 0 15px 35px rgba(0,0,0,0.1); width: 100%; }
        .about-image img { width: 100%; height: auto; display: block; transition: transform 0.6s ease; }
        .about-image:hover img { transform: scale(1.03); }

        .services { background: var(--cream); padding: 4rem 1.5rem; width: 100%; }
        .services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; max-width: 1200px; margin: 0 auto; width: 100%; }
        .service-card { background: var(--white); border-radius: 12px; overflow: hidden; box-shadow: 0 8px 25px rgba(0,0,0,0.06); transition: all 0.4s ease; position: relative; display: flex; flex-direction: column; height: 100%; }
        .service-card:hover { transform: translateY(-6px); box-shadow: 0 15px 35px rgba(0,0,0,0.1); }
        .service-image { height: 180px; overflow: hidden; position: relative; flex-shrink: 0; }
        .service-image img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s ease; }
        .service-card:hover .service-image img { transform: scale(1.08); }
        .service-content { padding: 1.3rem; display: flex; flex-direction: column; flex-grow: 1; }
        .service-content h3 { font-size: 1.15rem; margin-bottom: 0.6rem; color: var(--text-dark); }
        .service-content p { color: var(--text-light); margin-bottom: 0.8rem; line-height: 1.6; font-size: 0.9rem; flex-grow: 1; }
        .service-content ul { list-style: none; margin-bottom: 1.2rem; }
        .service-content ul li { padding: 0.25rem 0; color: var(--text-light); position: relative; padding-left: 1.3rem; font-size: 0.85rem; }
        .service-content ul li::before { content: '✓'; position: absolute; left: 0; color: var(--primary); font-weight: bold; }
        .service-content .btn { align-self: flex-start; margin-top: auto; padding: 0.6rem 1.2rem; font-size: 0.85rem; }

        .gallery { background: var(--white); padding: 4rem 1.5rem; width: 100%; }
        .gallery-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.2rem; max-width: 1200px; margin: 0 auto; width: 100%; }
        .gallery-item { position: relative; overflow: hidden; border-radius: 10px; cursor: pointer; aspect-ratio: 4/3; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
        .gallery-item img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s ease; }
        .gallery-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(212, 165, 165, 0.9); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.4s ease; }
        .gallery-item:hover .gallery-overlay { opacity: 1; }
        .gallery-item:hover img { transform: scale(1.1); }
        .gallery-overlay i { color: var(--white); font-size: 1.8rem; }

        .quote-section { background: linear-gradient(135deg, var(--secondary) 0%, var(--accent) 100%); padding: 4rem 1.5rem; text-align: center; width: 100%; }
        .quote-form { max-width: 1100px; margin: 0 auto; background: var(--white); padding: 2rem; border-radius: 16px; box-shadow: 0 15px 50px rgba(0,0,0,0.08); width: 100%; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; margin-bottom: 1.2rem; }
        .form-group { text-align: left; }
        .form-group.full { grid-column: 1 / -1; }
        .form-group label { display: block; margin-bottom: 0.4rem; color: var(--text-dark); font-weight: 500; font-size: 0.85rem; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 0.8rem; border: 2px solid var(--accent); border-radius: 8px; font-family: 'Montserrat', sans-serif; transition: all 0.3s ease; font-size: 0.95rem; background: var(--white); }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(212, 165, 165, 0.1); }
        .form-group textarea { resize: vertical; min-height: 100px; }

        .quote-builder { margin-top: 1.5rem; display: grid; grid-template-columns: 1.7fr 1fr; gap: 1.2rem; text-align: left; }
        .catalog { background: var(--cream); border: 1px solid var(--accent); border-radius: 12px; padding: 1rem; }
        .catalog-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.8rem; }
        .catalog-title { font-weight: 600; color: var(--text-dark); }
        .pill { display: inline-flex; align-items: center; gap: 0.35rem; background: var(--white); border: 1px solid var(--accent); border-radius: 999px; padding: 0.25rem 0.6rem; font-size: 0.75rem; color: var(--text-light); }
        .catalog-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.8rem; max-height: 420px; overflow: auto; padding-right: 0.25rem; }
        .item { background: var(--white); border: 1px solid var(--accent); border-radius: 10px; overflow: hidden; display: grid; grid-template-columns: 90px 1fr; min-height: 90px; }
        .item img { width: 100%; height: 100%; object-fit: cover; }
        .item-body { padding: 0.6rem 0.7rem; display: flex; flex-direction: column; gap: 0.35rem; }
        .item-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 0.5rem; }
        .item-name { font-size: 0.9rem; font-weight: 600; color: var(--text-dark); line-height: 1.2; }
        .item-cat { font-size: 0.7rem; color: var(--primary-dark); background: #fff; border: 1px solid var(--accent); padding: 0.1rem 0.4rem; border-radius: 999px; }
        .item-price { font-size: 0.8rem; color: var(--text-light); }
        .qty { display: flex; align-items: center; gap: 0.4rem; margin-top: auto; }
        .qty button { width: 28px; height: 28px; border-radius: 6px; border: 1px solid var(--accent); background: var(--white); cursor: pointer; font-weight: 600; transition: all 0.2s; }
        .qty button:hover { background: var(--primary); color: white; border-color: var(--primary); }
        .qty input { width: 56px; padding: 0.35rem 0.4rem; border: 1px solid var(--accent); border-radius: 6px; text-align: center; font-size: 0.9rem; }

        .summary { background: var(--white); border: 1px solid var(--accent); border-radius: 12px; padding: 1rem; position: sticky; top: 100px; }
        .summary h4 { font-family: 'Montserrat', sans-serif; font-weight: 600; margin-bottom: 0.6rem; color: var(--text-dark); }
        .summary .line { display: flex; align-items: center; justify-content: space-between; padding: 0.35rem 0; font-size: 0.95rem; }
        .summary .line.total { font-weight: 600; border-top: 1px dashed var(--accent); margin-top: 0.4rem; padding-top: 0.6rem; }
        .summary .muted { color: var(--text-light); font-size: 0.8rem; }
        .summary .actions { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin-top: 0.8rem; }

        .signature-preview { margin-top: 0.8rem; padding: 0.8rem; background: var(--cream); border: 1px dashed var(--accent); border-radius: 8px; text-align: center; }
        .signature-preview img { max-width: 100%; height: 60px; object-fit: contain; background: white; padding: 4px; border-radius: 4px; }
        .signature-preview .no-sig { color: var(--text-light); font-size: 0.85rem; font-style: italic; }

        .testimonials { background: var(--cream); padding: 4rem 1.5rem; width: 100%; }
        .testimonials-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; max-width: 1200px; margin: 0 auto; width: 100%; }
        .testimonial-card { background: var(--white); padding: 1.8rem; border-radius: 12px; box-shadow: 0 8px 25px rgba(0,0,0,0.04); position: relative; transition: transform 0.3s ease; }
        .testimonial-card:hover { transform: translateY(-3px); }
        .testimonial-card::before { content: '"'; font-family: 'Cormorant Garamond', serif; font-size: 3.5rem; color: var(--primary); opacity: 0.15; position: absolute; top: 5px; left: 15px; line-height: 1; }
        .stars { color: var(--gold); margin-bottom: 0.8rem; font-size: 0.85rem; }
        .testimonial-text { font-style: italic; color: var(--text-light); margin-bottom: 1.2rem; line-height: 1.7; position: relative; z-index: 1; font-size: 0.95rem; }
        .testimonial-author { display: flex; align-items: center; gap: 0.8rem; }
        .author-avatar { width: 42px; height: 42px; border-radius: 50%; background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%); display: flex; align-items: center; justify-content: center; color: var(--white); font-weight: 600; font-size: 0.9rem; flex-shrink: 0; }
        .author-info h4 { color: var(--text-dark); font-size: 0.95rem; margin-bottom: 0.1rem; }
        .author-info p { color: var(--text-light); font-size: 0.8rem; }

        .contact { background: var(--white); padding: 4rem 1.5rem; width: 100%; }
        .contact-content { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; max-width: 1200px; margin: 0 auto; width: 100%; }
        .contact-info h3 { font-size: 1.5rem; margin-bottom: 1rem; color: var(--text-dark); }
        .contact-info > p { color: var(--text-light); margin-bottom: 1.5rem; line-height: 1.7; font-size: 0.95rem; }
        .contact-details { margin-bottom: 1.5rem; }
        .contact-item { display: flex; align-items: flex-start; gap: 0.8rem; margin-bottom: 1.2rem; }
        .contact-item i { font-size: 1.1rem; color: var(--primary); margin-top: 0.2rem; width: 20px; text-align: center; flex-shrink: 0; }
        .contact-item div h4 { margin-bottom: 0.2rem; color: var(--text-dark); font-size: 0.95rem; }
        .contact-item div p { color: var(--text-light); line-height: 1.5; font-size: 0.9rem; }
        .contact-item a { color: var(--primary-dark); text-decoration: none; transition: color 0.3s; font-weight: 500; }
        .contact-item a:hover { color: var(--text-dark); text-decoration: underline; }
        .social-links { display: flex; gap: 0.6rem; margin-top: 1.2rem; }
        .social-links a { width: 40px; height: 40px; border-radius: 50%; background: var(--cream); display: flex; align-items: center; justify-content: center; color: var(--primary); text-decoration: none; transition: all 0.3s ease; font-size: 1rem; }
        .social-links a:hover { background: var(--primary); color: var(--white); transform: translateY(-2px); box-shadow: 0 4px 12px rgba(212, 165, 165, 0.3); }
        .map-container { background: var(--cream); border-radius: 12px; overflow: hidden; height: 100%; min-height: 350px; display: flex; align-items: center; justify-content: center; position: relative; border: 2px solid var(--accent); }
        .map-placeholder { text-align: center; color: var(--text-light); padding: 1.5rem; }
        .map-placeholder i { font-size: 2.5rem; color: var(--primary); margin-bottom: 0.8rem; }
        .map-placeholder h3 { color: var(--text-dark); margin-bottom: 0.4rem; font-size: 1.2rem; }
        .map-placeholder p { margin-bottom: 0.4rem; line-height: 1.5; font-size: 0.9rem; }

        footer { background: var(--text-dark); color: var(--white); padding: 2.5rem 1.5rem 1.2rem; width: 100%; }
        .footer-content { max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 2rem; margin-bottom: 2rem; width: 100%; }
        .footer-section h3 { color: var(--primary); margin-bottom: 1rem; font-size: 1.1rem; }
        .footer-section p { color: #bbb; line-height: 1.7; margin-bottom: 0.6rem; font-size: 0.85rem; }
        .footer-section ul { list-style: none; }
        .footer-section ul li { margin-bottom: 0.5rem; }
        .footer-section ul li a { color: #bbb; text-decoration: none; transition: all 0.3s; display: inline-block; font-size: 0.85rem; }
        .footer-section ul li a:hover { color: var(--primary); transform: translateX(3px); }
        .footer-phone { font-size: 1.1rem; color: var(--primary); font-weight: 600; display: inline-flex; align-items: center; margin-top: 0.3rem; text-decoration: none; transition: color 0.3s; }
        .footer-phone:hover { color: var(--white); }
        .footer-bottom { text-align: center; padding-top: 1.2rem; border-top: 1px solid #555; color: #999; font-size: 0.8rem; max-width: 1200px; margin: 0 auto; }

        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); backdrop-filter: blur(4px); z-index: 10000; display: none; align-items: center; justify-content: center; padding: 1rem; }
        .modal-overlay.active { display: flex; }
        .modal-content { background: white; padding: 2rem; border-radius: 16px; text-align: center; max-width: 420px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.3); animation: modalIn 0.3s ease; }
        @keyframes modalIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }
        .modal-content i { color: var(--primary); font-size: 3rem; margin-bottom: 0.8rem; }
        .modal-content h3 { margin-bottom: 0.8rem; color: var(--text-dark); font-size: 1.3rem; }
        .modal-content p { color: var(--text-light); margin-bottom: 1.2rem; line-height: 1.6; font-size: 0.95rem; }
        .modal-content button { background: var(--primary); color: white; border: none; padding: 0.8rem 2rem; border-radius: 50px; cursor: pointer; font-weight: 500; font-size: 0.95rem; transition: all 0.3s; }
        .modal-content button:hover { background: var(--primary-dark); transform: translateY(-2px); }

        .signature-modal .modal-content { max-width: 520px; text-align: left; }
        .signature-pad { width: 100%; height: 220px; border: 2px solid var(--accent); border-radius: 12px; background: white; touch-action: none; cursor: crosshair; }
        .signature-actions { display: flex; gap: 0.6rem; margin-top: 1rem; justify-content: space-between; }
        .signature-actions .left { display: flex; gap: 0.6rem; }

        .fade-in { opacity: 0; transform: translateY(20px); transition: all 0.5s ease; }
        .fade-in.visible { opacity: 1; transform: translateY(0); }

        img, video, canvas, iframe { max-width: 100%; height: auto; }
        * { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }

        @media (max-width: 968px) {
          .about-content, .contact-content { grid-template-columns: 1fr; gap: 2.5rem; }
          .values { grid-template-columns: 1fr; }
          .about-image { order: -1; max-width: 500px; margin: 0 auto; }
          .quote-builder { grid-template-columns: 1fr; }
          .summary { position: static; }
        }

        @media (max-width: 768px) {
          .top-bar { height: 28px; padding: 0.3rem 0.8rem; font-size: 0.75rem; }
          .top-bar-text { display: none; }
          header { top: 28px; height: 55px; }
          nav { padding: 0 1rem; }
          .logo { font-size: 1.2rem; }
          .logo i { font-size: 0.9rem; }
          .nav-links { display: none; position: absolute; top: 100%; left: 0; width: 100%; background: var(--white); flex-direction: column; padding: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,0.1); gap: 0.8rem; border-top: 1px solid var(--accent); max-height: calc(100vh - 83px); overflow-y: auto; }
          .nav-links.active { display: flex; }
          .nav-links a { font-size: 0.95rem; padding: 0.6rem 0; width: 100%; text-align: center; }
          .nav-links .btn { margin: 0.5rem 0 0 0; width: 100%; max-width: 200px; }
          .mobile-menu { display: block; }
          .hero { margin-top: 83px; min-height: calc(100vh - 83px); }
          .hero-content { padding: 1.5rem 1rem; }
          .hero-buttons { flex-direction: column; align-items: center; width: 100%; padding: 0 0.5rem; gap: 0.6rem; }
          .btn { width: 100%; max-width: 260px; padding: 0.8rem 1.5rem; font-size: 0.9rem; }
          .scroll-indicator { display: none; }
          .slider-dots { bottom: 15px; gap: 8px; }
          .dot { width: 8px; height: 8px; }
          section { padding: 3rem 1rem; }
          .section-title { margin-bottom: 2rem; }
          .services-grid, .gallery-grid, .testimonials-grid { grid-template-columns: 1fr; gap: 1.2rem; }
          .service-image { height: 160px; }
          .quote-form { padding: 1.5rem; }
          .form-grid { grid-template-columns: 1fr; gap: 1rem; }
          .catalog-grid { grid-template-columns: 1fr; }
          .map-container { min-height: 280px; }
          .footer-content { grid-template-columns: 1fr; gap: 1.8rem; text-align: center; }
          .social-links { justify-content: center; }
        }
      `}</style>

      {/* Signature Modal */}
      <div className={`modal-overlay signature-modal ${signatureModalOpen ? "active" : ""}`} onClick={(e) => e.target === e.currentTarget && setSignatureModalOpen(false)}>
        <div className="modal-content">
          <h3 style={{ textAlign: "center", marginBottom: "0.5rem" }}>
            <i className="fas fa-signature" style={{ color: "var(--primary)", marginRight: "0.5rem", fontSize: "1.2rem" }}></i>
            Signature du devis
          </h3>
          <p style={{ textAlign: "center", fontSize: "0.9rem", marginBottom: "1rem", color: "var(--text-light)" }}>
            Signez ci-dessous pour valider votre demande de devis
          </p>
          <canvas
            ref={signatureCanvasRef}
            className="signature-pad"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
          />
          <p style={{ fontSize: "0.75rem", color: "var(--text-light)", textAlign: "center", marginTop: "0.5rem" }}>
            Signez avec votre souris ou votre doigt
          </p>
          <div className="signature-actions">
            <div className="left">
              <button type="button" className="btn btn-cream" onClick={clearSignature} style={{ padding: "0.6rem 1.2rem", fontSize: "0.85rem" }}>
                <i className="fas fa-eraser" style={{ marginRight: 6 }}></i>Effacer
              </button>
            </div>
            <div style={{ display: "flex", gap: "0.6rem" }}>
              <button type="button" className="btn btn-cream" onClick={() => setSignatureModalOpen(false)} style={{ padding: "0.6rem 1.2rem", fontSize: "0.85rem" }}>
                Annuler
              </button>
              <button type="button" className="btn" onClick={saveSignature} style={{ padding: "0.6rem 1.2rem", fontSize: "0.85rem" }}>
                <i className="fas fa-check" style={{ marginRight: 6 }}></i>Valider la signature
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <div className={`modal-overlay ${modalOpen ? "active" : ""}`} id="modal" onClick={(e) => e.target === e.currentTarget && setModalOpen(false)}>
        <div className="modal-content">
          <i className="fas fa-check-circle"></i>
          <h3>Devis signé avec succès !</h3>
          <p>
            <strong>Référence : {quoteRef}</strong><br />
            Votre demande a été enregistrée.<br />
            Nous vous recontacterons très rapidement au <strong>0492 85 91 27</strong>.
          </p>
          {signatureData && (
            <div style={{ margin: "1rem 0", padding: "0.8rem", background: "var(--cream)", borderRadius: "8px" }}>
              <p style={{ fontSize: "0.8rem", marginBottom: "0.4rem", color: "var(--text-dark)", fontWeight: 500 }}>Signature validée</p>
              <img src={signatureData} alt="Signature" style={{ maxWidth: "200px", height: "50px", objectFit: "contain", background: "white", padding: "4px", borderRadius: "4px" }} />
            </div>
          )}
          <p style={{ fontSize: "0.85rem", color: "var(--text-light)", marginBottom: "1.2rem" }}>
            Total estimé : <strong style={{ color: "var(--primary-dark)" }}>{formatPrice(totals.total)}</strong>
          </p>
          <div style={{ display: "flex", gap: "0.6rem", justifyContent: "center" }}>
            <button onClick={() => setModalOpen(false)} style={{ background: "var(--primary)" }}>Fermer</button>
          </div>
        </div>
      </div>

      {/* Top Bar */}
      <div className="top-bar">
        <div className="top-bar-content">
          <div className="top-bar-left">
            <a href="tel:0492859127"><i className="fas fa-phone"></i> 0492 85 91 27</a>
          </div>
          <span className="top-bar-text">Intervention sur toute la Belgique</span>
        </div>
      </div>

      {/* Header */}
      <header id="header" className={scrolled ? "scrolled" : ""}>
        <nav>
          <a href="#" className="logo" onClick={(e) => { e.preventDefault(); scrollToId("accueil"); }}>
            <i className="fas fa-gem"></i>
            Tessa <span>&</span> D Events
          </a>
          <ul className={`nav-links ${mobileOpen ? "active" : ""}`} id="navLinks">
            <li><a href="#accueil" onClick={(e) => { e.preventDefault(); scrollToId("accueil"); }}>Accueil</a></li>
            <li><a href="#prestations" onClick={(e) => { e.preventDefault(); scrollToId("prestations"); }}>Prestations</a></li>
            <li><a href="#galerie" onClick={(e) => { e.preventDefault(); scrollToId("galerie"); }}>Galerie</a></li>
            <li><a href="#devis" onClick={(e) => { e.preventDefault(); scrollToId("devis"); }}>Devis</a></li>
            <li><a href="#contact" onClick={(e) => { e.preventDefault(); scrollToId("contact"); }}>Contact</a></li>
            <li><a href="tel:0492859127" className="btn">Appelez-nous</a></li>
          </ul>
          <button className="mobile-menu" id="mobileMenu" aria-label="Menu" onClick={() => setMobileOpen(!mobileOpen)}>
            <i className={`fas ${mobileOpen ? "fa-times" : "fa-bars"}`}></i>
          </button>
        </nav>
      </header>

      {/* Hero */}
      <section className="hero" id="accueil">
        <div className="hero-slider">
          {slides.map((src, i) => (
            <div key={src} className={`slide ${i === slide ? "active" : ""}`} style={{ backgroundImage: `url('${src}')` }} />
          ))}
        </div>
        <div className="hero-content">
          <h1>Votre Mariage, Notre Passion</h1>
          <p>Location de mobilier et décoration d'exception pour des moments inoubliables en Belgique</p>
          <div className="hero-buttons">
            <a href="#devis" className="btn" onClick={(e) => { e.preventDefault(); scrollToId("devis"); }}>Demander un devis</a>
            <a href="#contact" className="btn btn-outline" onClick={(e) => { e.preventDefault(); scrollToId("contact"); }}>Contactez-nous</a>
          </div>
        </div>
        <div className="slider-dots">
          {slides.map((_, i) => (
            <span key={i} className={`dot ${i === slide ? "active" : ""}`} onClick={() => setSlide(i)} />
          ))}
        </div>
        <div className="scroll-indicator">
          <i className="fas fa-chevron-down"></i>
        </div>
      </section>

      {/* About */}
      <section className="about" id="apropos">
        <div className="about-content">
          <div className="about-text fade-in">
            <h3>Créateurs d'Ambiances Uniques</h3>
            <p>Chez Tessa & D Events, nous transformons vos rêves en réalité. Spécialisés dans la location de mobilier et la décoration de mariage en Belgique, nous mettons notre expertise et notre créativité au service de votre événement.</p>
            <p>De la cérémonie laïque à la réception, nous vous accompagnons dans la création d'une atmosphère qui vous ressemble, alliant élégance, raffinement et attention aux détails.</p>
            
            <div className="values">
              <div className="value-card">
                <i className="fas fa-heart"></i>
                <h4>Passion</h4>
                <p>Chaque mariage est unique et mérite toute notre attention</p>
              </div>
              <div className="value-card">
                <i className="fas fa-award"></i>
                <h4>Qualité</h4>
                <p>Des matériaux premium et un service irréprochable</p>
              </div>
              <div className="value-card">
                <i className="fas fa-handshake"></i>
                <h4>Confiance</h4>
                <p>À vos côtés de la conception au jour J</p>
              </div>
            </div>
          </div>
          <div className="about-image fade-in">
            <img src="https://kimi-web-img.moonshot.cn/img/generalwax.com/195b4e0974eda929d87e448850b320302f08d2cd.jpg" alt="Décoration de table élégante" />
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="services" id="prestations">
        <div className="section-title fade-in">
          <h2>Nos Prestations</h2>
          <p>Des solutions complètes pour sublimer votre événement, de la location de mobilier à la décoration florale</p>
        </div>
        
        <div className="services-grid">
          <div className="service-card fade-in">
            <div className="service-image">
              <img src="https://kimi-web-img.moonshot.cn/img/apexpartyrentals.com/6b40b956491cb5c6db5fb5df33bdb1a0af2792cd.png" alt="Location de chaises" loading="lazy" />
            </div>
            <div className="service-content">
              <h3>Location de Mobilier</h3>
              <p>Des chaises Chiavari aux tables en bois massif, découvrez notre sélection de mobilier haut de gamme pour votre réception.</p>
              <ul>
                <li>Chaises Chiavari (or, argent, transparent)</li>
                <li>Tables rondes et rectangulaires</li>
                <li>Bar et tabourets</li>
                <li>Lounge et mobilier d'extérieur</li>
              </ul>
              <a href="#devis" className="btn" onClick={(e) => { e.preventDefault(); scrollToId("devis"); }}>En savoir plus</a>
            </div>
          </div>

          <div className="service-card fade-in">
            <div className="service-image">
              <img src="https://kimi-web-img.moonshot.cn/img/www.valarflowers.com/7694f3d1efe594fcdabada3b81a880d99baac204.jpg" alt="Arche florale" loading="lazy" />
            </div>
            <div className="service-content">
              <h3>Décoration Florale</h3>
              <p>Des compositions florales sur mesure pour créer l'ambiance romantique et élégante de vos rêves.</p>
              <ul>
                <li>Arches et structures florales</li>
                <li>Centres de table</li>
                <li>Bouquets de mariée</li>
                <li>Décoration d'allée</li>
              </ul>
              <a href="#devis" className="btn" onClick={(e) => { e.preventDefault(); scrollToId("devis"); }}>En savoir plus</a>
            </div>
          </div>

          <div className="service-card fade-in">
            <div className="service-image">
              <img src="https://kimi-web-img.moonshot.cn/img/static.wixstatic.com/082df7346e0abe118e6cc7072f547e7e719e69ea.jpg" alt="Accessoires de décoration" loading="lazy" />
            </div>
            <div className="service-content">
              <h3>Accessoires & Détails</h3>
              <p>La touche finale qui fait toute la différence. Découvrez nos accessoires soigneusement sélectionnés.</p>
              <ul>
                <li>Vaisselle et verrerie</li>
                <li>Linge de table</li>
                <li>Éclairage et bougies</li>
                <li>Panneaux et signalétique</li>
              </ul>
              <a href="#devis" className="btn" onClick={(e) => { e.preventDefault(); scrollToId("devis"); }}>En savoir plus</a>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="gallery" id="galerie">
        <div className="section-title fade-in">
          <h2>Notre Galerie</h2>
          <p>Inspirez-vous de nos réalisations et imaginez votre propre décoration de rêve</p>
        </div>
        <div className="gallery-grid">
          {[
            ["https://kimi-web-img.moonshot.cn/img/curatedevents.com/9b872ae167562006ea644f8dac62b0b6f70150e5.webp", "Réception élégante sous tente"],
            ["https://kimi-web-img.moonshot.cn/img/www.valarflowers.com/6f23ab267ece9a083d78db6efe50fd05b94ac0ee.jpg", "Arche florale bohème"],
            ["https://kimi-web-img.moonshot.cn/img/www.venturarental.com/2b4e8fd1f092147e1c654b5ec72e77a2751614db.webp", "Table d'honneur luxueuse"],
            ["https://kimi-web-img.moonshot.cn/img/southerneventsonline.com/481751c14e2f8f338470b13820432221009cc867.jpg", "Salle de réception décorée"],
            ["https://kimi-web-img.moonshot.cn/img/generalwax.com/195b4e0974eda929d87e448850b320302f08d2cd.jpg", "Centre de table romantique"],
            ["https://kimi-web-img.moonshot.cn/img/treasuryontheplaza.com/0defb7378a71023e697a570c307e7cb49af4a89c.jpeg", "Cérémonie élégante"],
          ].map(([src, alt]) => (
            <div className="gallery-item fade-in" key={src as string}>
              <img src={src as string} alt={alt as string} loading="lazy" />
              <div className="gallery-overlay">
                <i className="fas fa-search-plus"></i>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quote / Devis */}
      <section className="quote-section" id="devis">
        <div className="section-title fade-in" style={{ color: "var(--text-dark)", marginBottom: "2rem" }}>
          <h2>Demandez votre Devis Gratuit</h2>
          <p>Composez votre location, signez électroniquement et recevez une estimation personnalisée</p>
        </div>

        <form className="quote-form fade-in" id="quoteForm" onSubmit={submitQuote}>
          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="nom">Nom complet *</label>
              <input id="nom" name="nom" required placeholder="Votre nom" value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email *</label>
              <input type="email" id="email" name="email" required placeholder="votre@email.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="form-group">
              <label htmlFor="telephone">Téléphone *</label>
              <input type="tel" id="telephone" name="telephone" placeholder="0492 85 91 27" required value={form.telephone} onChange={(e) => setForm({ ...form, telephone: e.target.value })} />
            </div>
            <div className="form-group">
              <label htmlFor="date">Date de l'événement</label>
              <input type="date" id="date" name="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div className="form-group">
              <label htmlFor="type">Type d'événement</label>
              <select id="type" name="type" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option value="mariage">Mariage</option>
                <option value="anniversaire">Anniversaire</option>
                <option value="entreprise">Événement d'entreprise</option>
                <option value="autre">Autre</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="invites">Nombre d'invités</label>
              <select id="invites" name="invites" value={form.invites} onChange={(e) => setForm({ ...form, invites: e.target.value })}>
                <option value="20-50">20-50</option>
                <option value="50-100">50-100</option>
                <option value="100-150">100-150</option>
                <option value="150+">150+</option>
              </select>
            </div>
            <div className="form-group full">
              <label htmlFor="lieu">Lieu / Ville</label>
              <input id="lieu" name="lieu" placeholder="Ex : Liège, Namur, Bruxelles…" value={form.lieu} onChange={(e) => setForm({ ...form, lieu: e.target.value })} />
            </div>
            <div className="form-group full">
              <label htmlFor="message">Décrivez votre projet *</label>
              <textarea id="message" name="message" placeholder="Dites-nous en plus sur votre vision, vos couleurs préférées, le style recherché..." required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
            </div>
          </div>

          {/* Système de devis */}
          <div className="quote-builder">
            <div className="catalog">
              <div className="catalog-header">
                <div className="catalog-title">Sélectionnez vos articles</div>
                <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
                  <span className="pill"><i className="fas fa-hashtag" /> Réf {quoteRef || "—"}</span>
                  <button type="button" className="btn btn-cream" onClick={resetQuote} title="Vider la sélection" style={{ padding: "0.4rem 0.8rem", fontSize: "0.8rem" }}>
                    Réinitialiser
                  </button>
                </div>
              </div>
              <div className="catalog-grid">
                {items.map((it) => (
                  <div className="item" key={it.id}>
                    <img src={it.image} alt={it.name} />
                    <div className="item-body">
                      <div className="item-top">
                        <div className="item-name">{it.name}</div>
                        <span className="item-cat">{it.category}</span>
                      </div>
                      <div className="item-price">{formatPrice(it.unitPrice)} / unité</div>
                      <div className="qty">
                        <button type="button" aria-label="Diminuer" onClick={() => updateQty(it.id, -1)}>-</button>
                        <input
                          type="number"
                          min={0}
                          value={it.qty}
                          onChange={(e) => setQty(it.id, parseInt(e.target.value || "0", 10))}
                        />
                        <button type="button" aria-label="Augmenter" onClick={() => updateQty(it.id, 1)}>+</button>
                        <span className="muted" style={{ marginLeft: "auto", fontSize: "0.8rem" }}>
                          {it.qty > 0 ? `Sous-total: ${formatPrice(it.qty * it.unitPrice)}` : "—"}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <aside className="summary">
              <h4>Récapitulatif</h4>
              <div className="line"><span>Articles sélectionnés</span><strong>{totals.count}</strong></div>
              <div className="line"><span>Sous-total HTVA</span><strong>{formatPrice(totals.subtotal)}</strong></div>
              <div className="line"><span>TVA 21%</span><strong>{formatPrice(totals.tva)}</strong></div>
              <div className="line total"><span>Total TTC estimé</span><strong>{formatPrice(totals.total)}</strong></div>
              <p className="muted" style={{ marginTop: "0.4rem" }}>
                Estimation indicative. Devis final confirmé après échange.
              </p>

              {selectedItems.length > 0 && (
                <div style={{ marginTop: "0.6rem", maxHeight: 120, overflow: "auto", borderTop: "1px solid var(--accent)", paddingTop: "0.6rem" }}>
                  {selectedItems.map((it) => (
                    <div key={it.id} className="line" style={{ fontSize: "0.85rem" }}>
                      <span>{it.name} × {it.qty}</span>
                      <strong>{formatPrice(it.unitPrice * it.qty)}</strong>
                    </div>
                  ))}
                </div>
              )}

              {/* Signature preview */}
              <div className="signature-preview">
                {signatureData ? (
                  <>
                    <div style={{ fontSize: "0.75rem", color: "var(--text-dark)", marginBottom: "0.3rem", fontWeight: 500 }}>
                      <i className="fas fa-check-circle" style={{ color: "var(--primary)", marginRight: "0.3rem" }}></i>
                      Signature validée
                    </div>
                    <img src={signatureData} alt="Signature" />
                    <button 
                      type="button" 
                      onClick={() => setSignatureModalOpen(true)}
                      style={{ marginTop: "0.4rem", fontSize: "0.75rem", background: "none", border: "none", color: "var(--primary-dark)", cursor: "pointer", textDecoration: "underline" }}
                    >
                      Modifier la signature
                    </button>
                  </>
                ) : (
                  <div className="no-sig">
                    <i className="fas fa-signature" style={{ display: "block", fontSize: "1.5rem", marginBottom: "0.3rem", opacity: 0.3 }}></i>
                    Aucune signature
                  </div>
                )}
              </div>

              <div className="actions">
                <button type="button" className="btn btn-cream" onClick={copyQuote} style={{ padding: "0.6rem", fontSize: "0.85rem" }}>
                  <i className="fas fa-copy" style={{ marginRight: 6 }}></i> {copied ? "Copié !" : "Copier"}
                </button>
                <button type="button" className="btn btn-cream" onClick={downloadQuote} style={{ padding: "0.6rem", fontSize: "0.85rem" }}>
                  <i className="fas fa-download" style={{ marginRight: 6 }}></i> Télécharger
                </button>
              </div>
              
              {!signatureData ? (
                <button type="button" onClick={() => totals.count > 0 ? setSignatureModalOpen(true) : alert("Veuillez d'abord sélectionner des articles")} className="btn" style={{ width: "100%", marginTop: "0.6rem", padding: "0.9rem", fontSize: "0.95rem", background: "var(--primary-dark)" }}>
                  <i className="fas fa-signature" style={{ marginRight: "0.5rem" }}></i>
                  Signer le devis
                </button>
              ) : (
                <button type="submit" className="btn" style={{ width: "100%", marginTop: "0.6rem", padding: "0.9rem", fontSize: "0.95rem" }}>
                  <i className="fas fa-paper-plane" style={{ marginRight: "0.5rem" }}></i>
                  Envoyer le devis signé
                </button>
              )}
              
              <p style={{ marginTop: "0.6rem", fontSize: "0.8rem", color: "var(--text-light)", textAlign: "center" }}>
                <i className="fas fa-shield-alt" style={{ marginRight: "0.3rem" }}></i>
                Signature électronique sécurisée
              </p>
            </aside>
          </div>
        </form>
      </section>

      {/* Testimonials */}
      <section className="testimonials">
        <div className="section-title fade-in">
          <h2>Ils nous ont fait confiance</h2>
          <p>Découvrez les témoignages de nos mariés</p>
        </div>
        <div className="testimonials-grid">
          {[
            {
              initials: "ML",
              name: "Marie & Laurent",
              date: "Mariage - Juin 2025",
              text: "Tessa & D Events a transformé notre salle en un véritable conte de fées. L'attention aux détails, la qualité du mobilier et la créativité de l'équipe ont dépassé toutes nos attentes. Nos invités sont encore émerveillés !",
            },
            {
              initials: "SD",
              name: "Sophie & David",
              date: "Mariage - Août 2025",
              text: "Un service impeccable du début à la fin. L'équipe a été à l'écoute de nos besoins et a su s'adapter à notre budget sans compromettre l'élégance. Les chaises Chiavari dorées ont fait sensation !",
            },
            {
              initials: "ET",
              name: "Emma & Thomas",
              date: "Mariage - Septembre 2025",
              text: "Professionnalisme, réactivité et créativité. Tessa & D Events a parfaitement compris notre vision d'un mariage champêtre chic. Je recommande vivement leurs services à tous les futurs mariés !",
            },
          ].map((t) => (
            <div className="testimonial-card fade-in" key={t.name}>
              <div className="stars">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
              </div>
              <p className="testimonial-text">{t.text}</p>
              <div className="testimonial-author">
                <div className="author-avatar">{t.initials}</div>
                <div className="author-info">
                  <h4>{t.name}</h4>
                  <p>{t.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="contact" id="contact">
        <div className="section-title fade-in">
          <h2>Contactez-nous</h2>
          <p>Prêts à donner vie à votre événement ? Parlons-en !</p>
        </div>
        <div className="contact-content">
          <div className="contact-info fade-in">
            <h3>Parlons de votre projet</h3>
            <p>Que vous ayez une vision précise ou que vous cherchiez l'inspiration, notre équipe est là pour vous accompagner dans la création de votre événement de rêve.</p>
            <div className="contact-details">
              <div className="contact-item">
                <i className="fas fa-phone-alt"></i>
                <div>
                  <h4>Téléphone</h4>
                  <p><a href="tel:0492859127">0492 85 91 27</a></p>
                  <p style={{ fontSize: "0.8rem", marginTop: "0.1rem", color: "var(--text-light)" }}>Du lundi au samedi, 9h-19h</p>
                </div>
              </div>
              <div className="contact-item">
                <i className="fas fa-envelope"></i>
                <div>
                  <h4>Email</h4>
                  <p><a href="mailto:contact@tessaetdevents.be">contact@tessaetdevents.be</a></p>
                </div>
              </div>
              <div className="contact-item">
                <i className="fas fa-map-marker-alt"></i>
                <div>
                  <h4>Zone d'intervention</h4>
                  <p>Toute la Belgique</p>
                  <p style={{ fontSize: "0.85rem", color: "var(--primary-dark)", fontWeight: 500 }}>Basés à Liège</p>
                </div>
              </div>
            </div>
            <div className="social-links">
              <a href="#" aria-label="Facebook"><i className="fab fa-facebook-f"></i></a>
              <a href="#" aria-label="Instagram"><i className="fab fa-instagram"></i></a>
              <a href="#" aria-label="Pinterest"><i className="fab fa-pinterest-p"></i></a>
              <a href="#" aria-label="LinkedIn"><i className="fab fa-linkedin-in"></i></a>
            </div>
          </div>

          <div className="map-container fade-in">
            <div className="map-placeholder">
              <i className="fas fa-map-marked-alt"></i>
              <h3>Intervention sur toute la Belgique</h3>
              <p>Liège, Bruxelles, Namur, Charleroi, Anvers...</p>
              <p style={{ marginBottom: "0.8rem" }}>et partout ailleurs selon vos besoins</p>
              <a href="tel:0492859127" className="btn" style={{ marginTop: "0.3rem", padding: "0.7rem 1.5rem", fontSize: "0.9rem" }}>
                <i className="fas fa-phone" style={{ marginRight: "0.4rem" }}></i>
                0492 85 91 27
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <div className="footer-content">
          <div className="footer-section">
            <h3>Tessa & D Events</h3>
            <p>Votre partenaire décoration et location de mobilier pour des mariages et événements d'exception en Belgique.</p>
            <a href="tel:0492859127" className="footer-phone">
              <i className="fas fa-phone" style={{ marginRight: "0.4rem" }}></i>
              0492 85 91 27
            </a>
          </div>
          <div className="footer-section">
            <h3>Liens rapides</h3>
            <ul>
              <li><a href="#accueil" onClick={(e) => { e.preventDefault(); scrollToId("accueil"); }}>Accueil</a></li>
              <li><a href="#prestations" onClick={(e) => { e.preventDefault(); scrollToId("prestations"); }}>Nos Prestations</a></li>
              <li><a href="#galerie" onClick={(e) => { e.preventDefault(); scrollToId("galerie"); }}>Galerie Photos</a></li>
              <li><a href="#devis" onClick={(e) => { e.preventDefault(); scrollToId("devis"); }}>Demander un devis</a></li>
              <li><a href="#contact" onClick={(e) => { e.preventDefault(); scrollToId("contact"); }}>Contact</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h3>Nos Services</h3>
            <ul>
              <li><a href="#prestations" onClick={(e) => { e.preventDefault(); scrollToId("prestations"); }}>Location de mobilier</a></li>
              <li><a href="#prestations" onClick={(e) => { e.preventDefault(); scrollToId("prestations"); }}>Décoration florale</a></li>
              <li><a href="#prestations" onClick={(e) => { e.preventDefault(); scrollToId("prestations"); }}>Accessoires de mariage</a></li>
              <li><a href="#prestations" onClick={(e) => { e.preventDefault(); scrollToId("prestations"); }}>Installation complète</a></li>
              <li><a href="#contact" onClick={(e) => { e.preventDefault(); scrollToId("contact"); }}>Conseil personnalisé</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h3>Contact</h3>
            <p>Basés à Liège, nous intervenons dans toute la Belgique pour faire de votre événement un moment magique et inoubliable.</p>
            <p style={{ marginTop: "0.8rem" }}>
              <i className="fas fa-phone" style={{ marginRight: "0.4rem", color: "var(--primary)" }}></i> 
              <a href="tel:0492859127" style={{ color: "var(--primary)", textDecoration: "none" }}>0492 85 91 27</a>
            </p>
            <p>
              <i className="fas fa-envelope" style={{ marginRight: "0.4rem", color: "var(--primary)" }}></i> 
              <a href="mailto:contact@tessaetdevents.be" style={{ color: "#bbb", textDecoration: "none" }}>contact@tessaetdevents.be</a>
            </p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2025 Tessa & D Events. Tous droits réservés. | Location mobilier et décoration mariage Belgique</p>
        </div>
      </footer>
    </div>
  );
}